/*
 * chatterbox Progetto del corso di LSO 2017
 *
 * Dipartimento di Informatica Università di Pisa
 * Docenti: Prencipe, Torquati
 *
 */
/**
 * @file listener.c
 * @brief File fittizio per lo scambio tra client
 *
 * @author Gaspare Ferraro 520549 
 * Si dichiara che il contenuto di questo file e' in ogni sua parte opera  
 * originale dell'autore  
 */


#ifndef LISTENER_C_
#define LISTENER_C_

int main(int argc, char *argv[]) { return 0; }

#endif /* LISTENER_C_ */
