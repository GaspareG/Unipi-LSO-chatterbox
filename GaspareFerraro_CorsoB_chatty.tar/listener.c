/*
 * chatterbox Progetto del corso di LSO 2017
 *
 * Dipartimento di Informatica Università di Pisa
 * Docenti: Prencipe, Torquati
 *
 * Autore: Gaspare Ferraro CORSO B - Matricola 520549
 * Tale sorgente è, in ogni sua parte, opera originale di Gaspare Ferraro
 */
/**
 * @file listener.c
 * @brief File fittizio per lo scambio tra client
 */


#ifndef LISTENER_C_
#define LISTENER_C_

int main(int argc, char *argv[]) { return 0; }

#endif /* LISTENER_C_ */
